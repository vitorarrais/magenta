from magenta.models.performance_rnn import performance_sequence_generator
from magenta.models.performance_rnn import gen

print('++++++++++++')
print(performance_sequence_generator.MAX_NOTE_DURATION_SECONDS)
print('++++++++++++')

print('++++++++++++')
gen.hello()
print('++++++++++++')

